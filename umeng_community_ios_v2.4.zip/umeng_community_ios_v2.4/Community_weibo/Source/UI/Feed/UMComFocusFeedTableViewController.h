//
//  UMComMicroFeedTableViewController.h
//  UMCommunity
//
//  Created by 张军华 on 16/2/24.
//  Copyright © 2016年 Umeng. All rights reserved.
//

#import "UMComFeedTableViewController.h"

/**
 *  我的关注feed流ViewController
 */
@interface UMComFocusFeedTableViewController : UMComFeedTableViewController

@end
