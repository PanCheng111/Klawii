//
//  UMComFavouratesViewController.h
//  UMCommunity
//
//  Created by Gavin Ye on 8/12/15.
//  Copyright (c) 2015 Umeng. All rights reserved.
//

#import "UMComFeedTableViewController.h"

@interface UMComFavouratesViewController : UMComFeedTableViewController


@end
