//
//  UMComProgressView.h
//  UMCommunity
//
//  Created by luyiyuan on 14/9/3.
//  Copyright (c) 2014年 luyiyuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UMComProgressView : UIView
@property (assign, nonatomic) float progress;

- (id)initWithColor:(UIColor *)color;
@end
