//
//  UMComGridTableViewCellOne.h
//  UMCommunity
//
//  Created by luyiyuan on 14/10/16.
//  Copyright (c) 2014年 Umeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UMComGridTableViewCellOne : UIView

//@required
+ (CGSize)staticSize;
//

- (void)setWithData:(id)data;
@end
