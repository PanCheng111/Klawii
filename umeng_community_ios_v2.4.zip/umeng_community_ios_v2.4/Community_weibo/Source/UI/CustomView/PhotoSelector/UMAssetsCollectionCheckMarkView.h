//
//  UMAssetsCollectionCheckMarkView.h
//  UMCommunity
//
//  Created by luyiyuan on 14/9/9.
//  Copyright (c) 2014年 Umeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UMAssetsCollectionCheckMarkView : UIView

@end
