//
//  UMImagePickerGroupCell.h
//  UMCommunity
//
//  Created by luyiyuan on 14/9/9.
//  Copyright (c) 2014年 Umeng. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <AssetsLibrary/AssetsLibrary.h>

@interface UMImagePickerGroupCell : UITableViewCell
@property (nonatomic, strong) ALAssetsGroup *assetsGroup;
@end
