//
//  UMComViewController.h
//  UMCommunity
//
//  Created by umeng on 15/9/14.
//  Copyright (c) 2015年 Umeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UMComViewController : UIViewController

@property (nonatomic, assign) BOOL doNotShowBackButton;

@end
