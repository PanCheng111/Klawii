
//
//  UMComSysLikeTableViewCell.h
//  UMCommunity
//
//  Created by umeng on 15/12/28.
//  Copyright © 2015年 Umeng. All rights reserved.
//

#import "UMComSysCommonTableViewCell.h"

@interface UMComSysLikeTableViewCell : UMComSysCommonTableViewCell

@end
