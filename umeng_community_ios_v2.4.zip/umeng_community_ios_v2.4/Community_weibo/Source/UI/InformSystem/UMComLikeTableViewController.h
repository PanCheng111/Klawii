//
//  UMComLikeTableViewController.h
//  UMCommunity
//
//  Created by umeng on 15/12/22.
//  Copyright © 2015年 Umeng. All rights reserved.
//

#import "UMComRequestTableViewController.h"

@interface UMComLikeTableViewController : UMComRequestTableViewController

@end
