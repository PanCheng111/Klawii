//
//  UMComCommentMenuViewController.h
//  UMCommunity
//
//  Created by umeng on 15/12/23.
//  Copyright © 2015年 Umeng. All rights reserved.
//

#import "UMComViewController.h"

@interface UMComCommentMenuViewController : UMComViewController

@end
