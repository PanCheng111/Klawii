//
//  UMComPrivateLetterTableViewController.h
//  UMCommunity
//
//  Created by umeng on 15/11/30.
//  Copyright © 2015年 Umeng. All rights reserved.
//

#import "UMComRequestTableViewController.h"
#import "UMComTableViewCell.h"

@class UMComImageView,UMComPrivateLetter;

@interface UMComPrivateLetterTableViewController : UMComRequestTableViewController

@end
