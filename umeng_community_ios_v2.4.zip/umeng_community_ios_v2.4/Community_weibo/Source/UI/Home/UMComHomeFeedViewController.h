//
//  UMComHomeFeedViewController.h
//  UMCommunity
//
//  Created by umeng on 15-4-2.
//  Copyright (c) 2015年 Umeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UMComViewController.h"

@interface UMComHomeFeedViewController : UMComViewController

@end
