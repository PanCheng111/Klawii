//
//  UMComShareDelegatehandler.h
//  UMCommunity
//
//  Created by umeng on 16/3/3.
//  Copyright © 2016年 Umeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UMComShareDelegateHandler : NSObject



@end
