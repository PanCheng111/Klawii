//
//  UMComImageUrl.h
//  UMCommunity
//
//  Created by umeng on 15/12/3.
//  Copyright © 2015年 Umeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "UMComManagedObject.h"

NS_ASSUME_NONNULL_BEGIN

@interface UMComImageUrl : UMComManagedObject

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "UMComImageUrl+CoreDataProperties.h"
