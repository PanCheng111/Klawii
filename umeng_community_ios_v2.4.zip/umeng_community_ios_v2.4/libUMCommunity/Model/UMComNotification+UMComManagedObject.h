//
//  UMComNotification+UMComManagedObject.h
//  UMCommunity
//
//  Created by umeng on 15/7/15.
//  Copyright (c) 2015年 Umeng. All rights reserved.
//

#import "UMComNotification.h"

void printNotification();

@interface UMComNotification (UMComManagedObject)

@end
