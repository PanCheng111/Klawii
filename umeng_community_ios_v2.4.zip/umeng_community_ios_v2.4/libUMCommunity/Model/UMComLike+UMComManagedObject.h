//
//  UMComLike+UMComManagedObject.h
//  UMCommunity
//
//  Created by Gavin Ye on 12/25/14.
//  Copyright (c) 2014 Umeng. All rights reserved.
//

#import "UMComLike.h"


void printLike();

@interface UMComLike (UMComManagedObject)

@end
