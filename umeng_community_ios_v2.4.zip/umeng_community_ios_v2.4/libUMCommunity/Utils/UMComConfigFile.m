//
//  UMComConfigFile.m
//  UMCommunity
//
//  Created by umeng on 15/11/13.
//  Copyright © 2015年 Umeng. All rights reserved.
//

#import "UMComConfigFile.h"

@implementation UMComConfigFile

NSInteger const kFeedContentLength = 5000;
NSInteger const kCommentLenght = 300;
CGFloat const kUMComRefreshOffsetHeight = 60.0f;
CGFloat const kUMComLoadMoreOffsetHeight = 50.0f;

@end
